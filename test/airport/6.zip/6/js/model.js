/**
 * Created by Janice on 2017/7/20.
 */
var food={
    food_id:'',
    food_img:'',
    food_name:'芝士西蓝花炒蛋',
    food_monthSell:230,
    food_per:100,
    food_price:43,
    food_left:true/false,
    food_style:true/false
};